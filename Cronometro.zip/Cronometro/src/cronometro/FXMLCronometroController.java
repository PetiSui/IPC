/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cronometro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.concurrent.Service;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

/**
 *
 * @author jsoler
 */
public class FXMLCronometroController implements Initializable {

    private static long prevTime = 0;
    private static long startTime = 0;
    private static long stopTime = 0;
    private static final int DELAY = 100;
    private boolean firstTime = true;
    private boolean stopped = false;

    private final StringProperty tiempo = new SimpleStringProperty();
    private Thread elhilo;
    private MyService misservicio;

    @FXML
    private HBox menu1Button;
    @FXML
    private HBox menu2Button;
    @FXML
    private Button pararButton;
    @FXML
    private Button vueltaButton;
    @FXML
    private HBox menu3Button;
    @FXML
    private Button reanudarButton;
    @FXML
    private Button reestablecerButton;
    @FXML
    private Label segundosLabel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        segundosLabel.textProperty().bind(tiempo);
        misservicio = new MyService();

        // segundosLabel.textProperty().bind(task.messageProperty());
    }

    @FXML
    private void iniciarCrono(ActionEvent event) {
        if (firstTime) {
            misservicio.start();
        } else {
            misservicio.restart();
        }

        menu1Button.setVisible(false);
        menu2Button.setVisible(true);
    }

    @FXML
    private void pararCrono(ActionEvent event) {
        misservicio.cancel();
        firstTime = false;
        stopped = true;
        menu2Button.setVisible(false);
        menu3Button.setVisible(true);

    }

    @FXML
    private void vueltaCrono(ActionEvent event) {
        //falta
    }

    @FXML
    private void reanudarCrono(ActionEvent event) {
        misservicio.restart();
        menu3Button.setVisible(false);
        menu2Button.setVisible(true);
    }

    @FXML
    private void reestablecerCrono(ActionEvent event) {
        startTime = prevTime = stopTime = 0;
        stopped = false;
        tiempo.setValue("00:00:00");
        menu3Button.setVisible(false);
        menu1Button.setVisible(true);
    }

    private class MyService extends Service<Void> {

        @Override
        protected Task<Void> createTask() {
            return new Task<Void>() {

                void calcula() {
                    long nowTime = System.currentTimeMillis();
                    Long elapsedTime = nowTime - prevTime;
                    Long totalTime = (nowTime - startTime) - stopTime;
                    prevTime = nowTime;

                    final Integer minutos = totalTime.intValue() / 60000;
                    final Integer resto = totalTime.intValue() % 60000;
                    final Integer segundos = resto / 1000;
                    final Integer centesimas = resto % 60;

                    Platform.runLater(() -> {
                        tiempo.setValue(String.format("%02d", minutos) + ":" + String.format("%02d", segundos) + ":" + String.format("%02d", centesimas));
                    });
                    //======================version con el updateMessage=========================================================
//                    updateMessage(String.format("%02d", minutos) + ":" + String.format("%02d", segundos) + ":" + String.format("%02d", centesimas));
                }

                @Override
                protected Void call() {
                    if (!stopped) {
                        startTime = System.currentTimeMillis();
                        prevTime = startTime;
                    } else {
                        long nowTime = System.currentTimeMillis();
                        Long elapsedTime = nowTime - prevTime;
                        stopTime = stopTime + elapsedTime;
                    }
                    while (true) {
                        try {
                            Thread.sleep(DELAY);
                        } catch (InterruptedException ex) {
                            if (isCancelled()) {
                                break;
                            }
                        }
                        if (isCancelled()) {
                            break;
                        }
                        calcula();
                    }
                    return null;
                }

                @Override
                protected void cancelled() {
                    super.cancelled();
                    prevTime = System.currentTimeMillis();
                }
            };
        }
    }

 
}
