/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moverbola;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;

/**
 *
 * @author jortaga1
 */
public class FXMLMoverBolaController implements Initializable {
    
    @FXML
    private Circle circulo;
    @FXML
    private GridPane grid;
    private static int size = 5;
    private int bola_x = 2;
    private int bola_y = 2;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        grid.requestFocus();
    }

    @FXML
    private void mover(KeyEvent event) {
        KeyCode code = event.getCode();
        event.consume(); //para consumir el evento y que ya no se use por otra cosa
        //bola_x -> GridPane.getRowIndex(circulo, bola_x);
        //bola_y -> GridPane.getColumnIndex(circulo, bola_y);
        switch(code){
            case UP:
                bola_y = ((bola_y - 1 + size) % size);
                GridPane.setRowIndex(circulo, bola_y);
                break;
            case DOWN:
                bola_y = ((bola_y + 1 + size) % size);
                GridPane.setRowIndex(circulo, bola_y);
                break;
            case LEFT:
                bola_x = ((bola_x - 1 + size ) % size);
                GridPane.setColumnIndex(circulo, bola_x);
                break;
            case RIGHT:
                bola_x = ((bola_x + 1 + size ) % size);
                GridPane.setColumnIndex(circulo, bola_x);
                break;    
        
        }
    }
    
}
