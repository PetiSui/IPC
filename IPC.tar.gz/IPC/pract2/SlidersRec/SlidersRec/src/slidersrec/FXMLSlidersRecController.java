/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package slidersrec;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author jortaga1
 */
public class FXMLSlidersRecController implements Initializable {
    
    @FXML
    private Rectangle rectangulo;
    @FXML
    private Slider hslider;
    @FXML
    private Slider vslider;
    @FXML
    private AnchorPane contenedor;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
//        hslider.valueProperty().addListener((a, b, c)->{
//            
//            rectangulo.setWidth((double) c);            
//            
//        });
//        
//        vslider.valueProperty().addListener((a, b, c)->{
//            
//            rectangulo.setHeight((double) c);            
//            
//        });
        
        rectangulo.widthProperty().bind(hslider.valueProperty());
        rectangulo.heightProperty().bind(vslider.valueProperty());
        
//        rectangulo.widthProperty().bind(Bindings.divide(contenedor.widthProperty(), 2));
//        rectangulo.heightProperty().bind(Bindings.divide(contenedor.heightProperty(), 2));
    }    
    
}
